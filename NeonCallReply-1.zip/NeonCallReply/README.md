# Responder

Android app that automatically texts people who call you, with a message for where you are.

## How to use
1. Open the app and choose where you are: **Mosque, Work, Business meeting, Market or Custom**.
2. Allow the Phone, Call log and SMS permissions.
3. Anyone who calls now gets your message by SMS (for example: "I'm in the mosque right now. Please call me later.").
4. Choose **Off** when you are free. If you do not open the app and choose a place, no message is sent.

You can edit the message for each place and tap Save.

## Build
Open this folder in Android Studio, or let GitHub build it: see `.github/workflows/build.yml`.

## Notes
- Android only (iOS does not allow automatic SMS).
- The same caller is not texted again within 5 minutes.
- Carrier SMS charges may apply.
