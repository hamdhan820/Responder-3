package com.neon.callreply

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return
        val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
        val p = c.getSharedPreferences("auto", Context.MODE_PRIVATE)
        val status = p.getString("status", "Off") ?: "Off"
        if (status == "Off") return  // nothing selected in the app: no message
        val now = System.currentTimeMillis()
        // Don't text the same caller again within 5 minutes
        if (p.getString("last_num", "") == number && now - p.getLong("last_time", 0) < 300_000) return
        p.edit().putString("last_num", number).putLong("last_time", now).apply()
        val text = Prefs.message(p, status)
        val sms = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        try { sms.sendMultipartTextMessage(number, null, sms.divideMessage(text), null, null) } catch (_: Exception) {}
    }
}
