package com.neon.callreply

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

object Prefs {
    val defaults = mapOf(
        "Mosque" to "I'm in the mosque right now. Please call me later.",
        "Work" to "I'm at work right now. I'll call you back later.",
        "Meeting" to "I'm in a business meeting. I'll call you back later.",
        "Market" to "I'm at the market right now. I'll call you back later.",
        "Custom" to "Sorry, I can't pick up right now. I'll call you back later."
    )
    fun message(p: SharedPreferences, status: String) =
        p.getString("msg_$status", defaults[status]) ?: ""
}

class MainActivity : AppCompatActivity() {
    private val ids = mapOf(
        R.id.rOff to "Off", R.id.rMosque to "Mosque", R.id.rWork to "Work",
        R.id.rMeeting to "Meeting", R.id.rMarket to "Market", R.id.rCustom to "Custom"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val prefs = getSharedPreferences("auto", Context.MODE_PRIVATE)
        val group = findViewById<RadioGroup>(R.id.group)
        val msg = findViewById<EditText>(R.id.message)
        val save = findViewById<Button>(R.id.save)
        val active = findViewById<TextView>(R.id.active)

        var current = prefs.getString("status", "Off")!!
        if (current !in ids.values) current = "Off"
        group.check(ids.entries.first { it.value == current }.key)

        fun show() {
            val on = current != "Off"
            msg.isEnabled = on
            save.isEnabled = on
            msg.setText(if (on) Prefs.message(prefs, current) else "")
            active.text = if (on) "ACTIVE: $current\nCallers get the message below."
                          else "AUTO-REPLY IS OFF\nChoose where you are."
        }
        show()

        group.setOnCheckedChangeListener { _, id ->
            current = ids[id]!!
            prefs.edit().putString("status", current).apply()
            if (current != "Off") ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.SEND_SMS),
                1
            )
            show()
        }
        save.setOnClickListener {
            prefs.edit().putString("msg_$current", msg.text.toString()).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        val bgs = intArrayOf(R.drawable.bg_cubes, R.drawable.bg_polygons, R.drawable.bg_swirl)
        var bi = prefs.getInt("bg", 0)
        val bg = findViewById<ImageView>(R.id.bg)
        bg.setImageResource(bgs[bi])
        findViewById<Button>(R.id.theme).setOnClickListener {
            bi = (bi + 1) % bgs.size
            prefs.edit().putInt("bg", bi).apply()
            bg.setImageResource(bgs[bi])
        }
    }
}
